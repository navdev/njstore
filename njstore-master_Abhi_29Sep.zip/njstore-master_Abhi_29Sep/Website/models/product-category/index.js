var productCategory = function(categoryName){
  this.categoryName = categoryName;
}

module.exports = productCategory;
