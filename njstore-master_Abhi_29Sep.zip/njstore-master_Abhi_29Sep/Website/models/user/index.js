var user = function(userName,password,email,firstName,lastName,address,phone,gender,birthday){
// var user = function(){ 
  this.userName = userName;
  this.password = password;
  this.email = email;
  this.firstName = firstName;
  this.lastName = lastName;
  this.address = address;
  this.phone = phone;
  this.gender = gender;
  this.birthday = birthday;
}

module.exports = user;
