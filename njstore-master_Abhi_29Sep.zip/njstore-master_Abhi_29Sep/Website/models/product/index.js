var product = function(productName){
  this.categoryId = "";
  this.productName = "";
  this.productType = "";
  this.description = "";
  this.price = "";
  this.imageSource = "";
}

module.exports = product;
