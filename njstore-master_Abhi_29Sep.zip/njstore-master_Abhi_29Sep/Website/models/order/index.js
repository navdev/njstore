var order = function(){
  this.orderId = "";
  this.userId = "";
  this.orderDate = "";
  this.totalPrice = "";
}

module.exports = order;
