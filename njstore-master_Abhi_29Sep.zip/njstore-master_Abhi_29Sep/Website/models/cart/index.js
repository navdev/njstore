var cart = function(){
  this.productId = "";
  this.userId = "";
  this.quantity = "";
}

module.exports = productCategory;
