var orderDetail = function(){
  this.orderId = "";
  this.productId = "";
  this.quantity = "";
  this.price = "";
  this.amount = "";
}

module.exports = orderDetail;
