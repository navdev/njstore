(function(){
    var app = angular.module("app", ["ngRoute"]);
    var apiUrl = "/api/";
    app.config(function($routeProvider, $locationProvider) {
        $routeProvider
            .when("/", {
                templateUrl : "templates/home",
                controller : "homeController"
            })
            .when("/single", {
                templateUrl : "templates/single",
                controller : "singleController"
            })
            .when("/register", {
                templateUrl : "templates/userprofile",
                controller : "userprofileController"
            })
            .when("/orderlist", {
                templateUrl : "templates/orderlist",
                controller : "orderlistController"
            })
            .when("/orderdtls", {
                templateUrl : "templates/orderdtls",
                controller : "userprofileController"
            })
            
            .otherwise("/");
/*
            $locationProvider.html5Mode({
                enabled: true,
                requireBase: false
            });
            */
    });

    app.controller("homeController", function ($scope) {
        $scope.msg = "I love white";
    });
    app.controller("singleController", function ($scope) {
        $scope.msg = "I love red";
        $scope.name = "Abhishek Kumar";
        $scope.email = "Abhi@abc.com";
    });

   app.controller('userprofileController', function($scope,$http) {
   $scope.submit=function(){
       $scope.myTxt = "You clicked submit!";
     
       console.log('$scope.userName : ' + $scope.userName);

        var data = {userName: 'Abhi' };

        console.log('Form Submitted'); 
  
        data =   {
            userName: $scope.userName,
            password: $scope.password,
            email: $scope.email,
            firstName: $scope.firstName,
            lastName: $scope.lastName,
            address: $scope.address,
            phone: $scope.phone,
            gender: $scope.gender,
            birthday: $scope.birthday

        };  
    
        console.log('data'+data ); 
     //$scope.statusMsg='Sending data to server...';
        console.log('Sending data to server...' );

        $http.post("/insertuser", data).success(function(status) {
     
        console.log('Data posted successfully');
        console.log('Status:'+ status)
      })
      
   }
});





   app.controller('orderlistController', function($scope,$http) {

       console.log("Inside orderlistController");
   $scope.onClick=function(){   
   }
        console.log("Inside orderlistController");

    $http.get("/order/orderlist").then(function(result){
        console.log(" Inside orderlistController. REtuened from Router Get : "+ result);
            
            console.log(result.data);
            $scope.orderlist = result.data;
        });

});







})();