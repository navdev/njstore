var express = require("express");
var router = express.Router();
var dbhelper = require("../helpers/dbhelper");
var productCategory = require("../models/product-category");
var user = require("../models/user");
var order = require("../models/order");

router.get("/", function(req, res, next) {
   res.render("index", {title: "Online Shopping", message: "My Message"});
});

router.get("/testpage", function(req, res, next) {
    res.render("testpage", {title: "test form"});
});

router.get("/servicedemo", function(req, res, next) {
    res.json({title: "test form"});
});


router.post("/testpage", function(req, res, next) {
    var pc = new productCategory(req.body.categoryName);
    console.log(pc);
    dbhelper.insert("productCategory", pc, function(result){
        console.log(result);
    });
    res.redirect("/testpage");
});

router.get("/partials/:name", function(req, res, next){
    var name = req.params.name;
    res.render("partials/" + name);
});

router.get("/templates/:name", function(req, res, next){
    var name = req.params.name;
    res.sendFile(appRoot + "/views/ng-templates/" + name + ".html");
});

router.post("/insertuser", function(req, res, next) {
 // router.post("/insertuser", function(req, res) {  
    //var pc = new productCategory(req.body.categoryName);
    /*
    console.log(pc);
    dbhelper.insert("productCategory", pc, function(result){
        console.log(result);
    });
    res.redirect("/testpage");
    */
console.log('Inside Routes Post Service /insertuser ');
console.log('REQUEST body ' + req.body);

var userName = req.body.userName;
var password = req.body.password;
var email = req.body.email;
var firstName = req.body.firstName;
var lastName = req.body.lastName;
var address = req.body.address;
var phone = req.body.phone;
var gender = req.body.gender;
var birthday = req.body.birthday;



console.log('REQUEST req.body.data ' + req.body.userName);
console.log('REQUEST req.body.data ' + req.body.password);
console.log('REQUEST req.body.data ' + req.body.email);
console.log('REQUEST req.body.data ' + req.body.firstName);
console.log('REQUEST req.body.data ' + req.body.lastName);
console.log('REQUEST req.body.data ' + req.body.address);
console.log('REQUEST req.body.data ' + req.body.phone);
console.log('REQUEST req.body.data ' + req.body.gender);
console.log('REQUEST req.body.data ' + req.body.birthday);

var userdetails = new user(userName,password,email,firstName,lastName,address,phone,gender,birthday);
//var userdetails = new user();
console.log('user ' + userdetails);

dbhelper.insert("user", userdetails, function(result){
        console.log(result);
    });
   // res.redirect("/userprofile");
    res.send(userName + ' ' + email );
});







router.get("/order/orderlist", function(req, res, next) {
    console.log("Inside Router orderlist Servicer");
    dbhelper.find("order", {}, function(result){
        console.log("Data Fetched" + result);
        res.json(result);
    });
});





module.exports = router;
